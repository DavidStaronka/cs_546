const userRoutes = require('./users');

module.exports = {
    users: userRoutes
};